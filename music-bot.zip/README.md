# Music Bot

Telegram music bot (simple version)

## Setup
1. Add BOT_TOKEN in Railway Variables
2. Run on Railway
