const TelegramBot = require("node-telegram-bot-api");

const token = process.env.BOT_TOKEN;
const bot = new TelegramBot(token, { polling: true });

bot.on("message", (msg) => {
  const chatId = msg.chat.id;
  const text = msg.text;

  if (text === "/start") {
    bot.sendMessage(chatId, "🎵 هلا بيك في بوت الأغاني");
  } else if (text.startsWith("/play")) {
    const query = text.replace("/play", "").trim();
    if (!query) {
      bot.sendMessage(chatId, "اكتب اسم الأغنية بعد /play");
      return;
    }
    bot.sendMessage(chatId, "جاري البحث عن: " + query + " 🎧 (تجريبي)");
  } else {
    bot.sendMessage(chatId, "استخدم /play اسم الأغنية");
  }
});
